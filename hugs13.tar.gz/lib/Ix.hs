-----------------------------------------------------------------------------
-- Standard Library: Ix operations
--
-- Suitable for use with Hugs 1.3.
-----------------------------------------------------------------------------

module Ix where

-- This module is empty; Ix is currently defined in the prelude, but should
-- eventually be moved to this library file instead.

-----------------------------------------------------------------------------
