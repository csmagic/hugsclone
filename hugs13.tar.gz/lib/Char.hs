-----------------------------------------------------------------------------
-- Standard Library: Char operations
--
-- Suitable for use with Hugs 1.3.
-----------------------------------------------------------------------------

module Char where

-- This module is empty; Char operations are currently defined in the
-- prelude, but should eventually be moved to this library file instead.

-----------------------------------------------------------------------------
